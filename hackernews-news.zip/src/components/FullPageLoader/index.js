export { default } from './FullPageLoader'
