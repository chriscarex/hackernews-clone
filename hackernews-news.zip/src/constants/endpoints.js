export const BASE_ENDPOINT = 'https://hacker-news.firebaseio.com/v0/'
export const ENDPOINT_NEWS = 'newstories.json'
export const ENDPOINT_ARTICLE = 'item/'
