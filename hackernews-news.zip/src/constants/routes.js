export const ROUTE_HOME = '/'
export const ROUTE_ARTICLE = '/:id'
