export {
  readLS, upsertLS, deleteLS, isLSEmpty, removeAllLSs
} from './localStorage'
export { getOptionsFromArrayOfStrings } from './getOptionsFromArrayOfStrings'
export { isRowContainingString } from './isRowContainingString'
